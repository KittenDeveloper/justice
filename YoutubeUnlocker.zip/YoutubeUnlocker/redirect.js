var currenturl;
function tabredirect(){
console.log("Redirecting...");
	chrome.tabs.getSelected(function(tab){
		currenturl = tab.url;
		console.log(currenturl);
		chrome.tabs.update(tab.id, {url: (currenturl.replace(currenturl.match(/(?=watch\?v\=)(.*)/)[1],"v/"+currenturl.match(/watch\?v=(.*)/)[1]+"?fs=1"))		});
		});
}
chrome.browserAction.onClicked.addListener(tabredirect)